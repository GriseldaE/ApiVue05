<script setup>
import { ref } from 'vue';
const datos = ref(null);
fetch(' https://jsonplaceholder.typicode.com/posts')
    .then(response => response.json())
    .then(data => datos.value = data);
</script>

<template>
    
  <table>
    <tr>
     <th>userId</th>
     <th>id</th>
     <th>title</th>
     <th>body</th>
    </tr>
    <tr v-for="product in datos" :key="product.id">
     <td>{{product.userId}}</td>
     <td>{{product.id}}</td>
     <td>{{product.title}}</td>
     <td>{{product.body}}</td>
    </tr>
 
  </table>
           
            
</template>